package kr.or.Izoa;

public class Manager {

}
