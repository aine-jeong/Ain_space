package kr.or.Izoa;

// 제일 메인!!!! 클래스~~~~

public class IzoaSalon {
    

}
