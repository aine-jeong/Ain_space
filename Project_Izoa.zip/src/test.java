import java.util.Scanner;

public class test {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        String id,pw;
        
        System.out.print("ID: ");
        id = sc.nextLine();
        System.out.print("PassWord: ");
        pw = sc.nextLine();
        
        
    }
}
