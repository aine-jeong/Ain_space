
public class IzoaSalon_main {

}
