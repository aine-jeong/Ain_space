import kr.or.bit.common.Fclass;

public class Ex02_MethodCall {
    public static void main(String[] args) {
        Fclass fclass = new Fclass();
        fclass.m(); // 함수 호출
        fclass.m2(100);
        
        int result = fclass.m3();
        System.out.println(result);
        
        result = fclass.m4(200);
        System.out.println(result);
    }
}
