package kr.or.bit.common;

public class Program {
    public static void main(String[] args) {
        Car car = new Car();
        AirPlane airplane = new AirPlane();
       
    }
}
