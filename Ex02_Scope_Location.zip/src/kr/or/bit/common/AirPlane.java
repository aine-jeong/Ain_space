package kr.or.bit.common;

class AirPlane { 
    // public 삭제
    // (default) class AirPlane : 디폴트가 생략되어 있는 것!

}
