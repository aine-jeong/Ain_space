package kr.or.bit.common;
/*
 클래스 구성요소 (필드 + 함수) 중 함수를 배워보자
 
 - 기능(행위)을 만드는 방법!
 - 함수(function, method)
 - method: 행위 또는 기능을 "최소단위"로 정의하는 것 >> 즉 하나의 함수는 하나의 기능만 구현한다.
  ex) 먹는다, 걷는다, 잔다 ...
  
 - 함수는 호출에 의해서만 동작된다.
 
 # JAVA)
    1. void, parameter(0)        >> void print(String str) { 실행 코드 }
       - void: return이 없당
       - parameter: 인수, 매개변수
       - 동전을 넣고 하는 게임기
       - 주는것 0, 받는것 x
    2. void, parameter(x)        >> void print() { 실행코드}
       - 동전을 넣지 않아도 할 수 있는 게임기
       - 주는것 x, 받는것 x
    3. return type, parameter(0) >> int print(int data) {return data + 10}
       - 주는것 0, 받는것 0              ㄴ 어떤 값을 주면 10을 더해서 돌려주겠다. 
                                  ( 그 어떤 값이 어떤 형태인지 표현하는 부분이 return type이다. 여기서는 int )
    4. return type, parameter(x) >> int print() {return 100;}
       - 주는것 x, 받는것0
       
       
    void: 돌려주는 것이 없다 >> return value가 없다
    return type >> 8가지 기본 타입, Array, Class, ... Collection, Interface 등
    parameter type >> 8가지 기본 타입, Array, Class, ... Collection, Interface 등
    
    parameter의 개수는 제한이 없다.
    void print(int a, int b, int c, int d) {}
    >> print(10, 20, 30) -> 정상 실행하지 않음
    >> 이 함수를 정상적으로 실행시키려면
    >> print(10, 20, 30, 40) : 주어진 파라미터의 개수와 똑같은 개수의 값을 넣어주어야 한다.
 
    ex)
    boolean print(bollean b) {return b};
    print(false);
    
    함수의 이름에는 관용적 표현이 있다.
    void a(){} ... (x)
    의미있는 단어의 조합
    getChnnelNumber()
    getEmpListByEmpno
 
 
 */
public class Fclass {
    public int data;
    
    // 4가지 기본 유형
    
    public void m() {// 리턴타입이 없고 파라미터가 없다
        System.out.println("일반함수: void, parameter(x)");
    }
    
    public void m2(int i) {// 리턴타입이 없고 파라미터가 있다
        System.out.println("일반함수: void, parameter(0)");
        System.out.println("parameter value: " + i);
    }
    
    public int m3() {// 리턴타입이 있고 파라미터가 없다
        return 100; // return type이 존재하면 반드시 return 키워드를 사용해야 한다.
    }
    
    public int m4(int data) {// 리턴타입이 있고 파라미터가 있다
        return 100+data;
    }

}



















